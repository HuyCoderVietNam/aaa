
        function kiemtra() {
            var flag = 0;
            var name = document.getElementById("name").value;
            if (name == "") {
                document.getElementById("baoloi").innerHTML = "Hãy điền tên của bạn.";
                flag++;
            } 
            else if (name.length > 50) {
                document.getElementById("baoloi").innerHTML =
                    "Tên không dài quá 50 kí tự.";
                flag++;
            }
            else if (name.length < 2) {
                    document.getElementById("baoloi").innerHTML =
                        "Tên phải ít nhất 2 kí tự.";
                    flag++;
            } 
            else {
                document.getElementById("baoloi").innerHTML =
                    "";
            }


            var phone = document.getElementById("phone").value;
            if (phone == "") {
                document.getElementById("baoloi1").innerHTML =
                    "Hãy điền số điện thoại của bạn.";
                flag++;
            } 
            else if (phone.length !=10) {
                document.getElementById("baoloi1").innerHTML =
                    "Số điện thoại phải là 10 số";
                flag++;
            } 
            else {
                document.getElementById("baoloi1").innerHTML =
                    "";
            }


            var tour = document.getElementById("tour").value;
            if (tour == "") {
                document.getElementById("baoloi2").innerHTML =
                    "Chọn Tour bạn muốn đặt.";
                flag++;
            } 
            else {
                document.getElementById("baoloi2").innerHTML =
                    "";
            }


            var pax = document.getElementById("pax").value;
            if (pax == "") {
                document.getElementById("baoloi3").innerHTML =
                    "Bạn muốn booking cho bao nhiêu người ?";
                flag++;
            } 
            else if (pax < 0) {
                document.getElementById("baoloi3").innerHTML =
                    "Vui lòng chọn ít nhất 1 người";
                flag++;
            } 
            else {
                document.getElementById("baoloi3").innerHTML =
                    "";
            }


            var date = document.getElementById("date").value;
            if (date == "") {
                document.getElementById("baoloi5").innerHTML =
                    "Vui lòng chọn ngày";
                flag++;
            } 
            else {
                document.getElementById("baoloi5").innerHTML =
                    "";
            }


            if (flag > 0) return false;
            alert("Booking thành công ! Chúng tôi sẽ liên hệ với bạn ngay. Cảm ơn bạn đã sử dụng dịch vụ của Dannang Travel by Huy");
            document.getElementById("form").submit();
        }
