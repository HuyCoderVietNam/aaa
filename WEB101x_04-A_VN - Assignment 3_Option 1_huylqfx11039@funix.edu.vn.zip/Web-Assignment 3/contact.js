
    function kiemtra() {
        var flag = 0;
        var name = document.getElementById("name").value;
        if (name == "") {
            document.getElementById("loi").innerHTML = "Hãy điền tên của bạn.";
            flag++;
        } 
        else if (name.length > 50) {
            document.getElementById("loi").innerHTML =
                "Tên không dài quá 50 kí tự.";
            flag++;
        } 
        else {
            document.getElementById("loi").innerHTML =
                "";
        }


        var phone = document.getElementById("phone").value;
        if (phone == "") {
            document.getElementById("loi2").innerHTML = "Hãy điền số điện thoại của bạn.";
            flag++;
        } 
        else if (phone.length !=10) {
            document.getElementById("loi2").innerHTML =
                "Số điện thoại phải là 10 số";
            flag++;
        } 
        else {
            document.getElementById("loi2").innerHTML =
                "";}


        var subjed = document.getElementById("subjed").value;
        if (subjed == "") {
            document.getElementById("loi3").innerHTML = "Vui lòng điền chủ đề bạn muốn liên hệ";
            flag++;
        } 
        else {
            document.getElementById("loi3").innerHTML =
                "";
        }


        var noidung = document.getElementById("noidung").value;
        if (noidung == "") {
            document.getElementById("loi4").innerHTML = "Vui lòng cho chúng tôi biết thông tin bạn muốn liên hệ";
            flag++;
        } 
        else if (noidung.length > 200) {
            document.getElementById("loi4").innerHTML =
                "Nội không dài quá 200 kí tự.";
            flag++;
        } 
        else {
            document.getElementById("loi4").innerHTML =
                "";
        }

        if (flag > 0) return false;
        alert("Cảm ơn bạn đã liên hệ với chúng tôi !");
        document.getElementById("form").submit();
    }
